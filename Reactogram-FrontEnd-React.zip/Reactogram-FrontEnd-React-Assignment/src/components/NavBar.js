import React from 'react'
import './NavBar.css';
import Logo from '../images/logo.PNG'
import { NavLink } from 'react-router-dom';

const NavBar = () => {
  return (
    <div>
      <nav className="navbar bg-light  shadow ">
        <div className="container-fluid">
          <NavLink className='navbar-brand ms-5 ' to="/" >
            <img alt="Logo" src={Logo} height={"45px"} />
          </NavLink>
          <form className="d-flex me-md-5">
            <input className="searchbox form-control me-2" type="search" placeholder="Search" aria-label="Search" />
            <a className="nav-link text-dark fs-5 searchIcon" href="#"><i className="fa-solid fa-magnifying-glass"></i></a>
            <a className="nav-link text-dark fs-5" href="#"><i className="fa-solid fa-house"></i></a>
            <a className="nav-link text-dark fs-5" href="#"><i className="fa-regular fa-heart"></i></a>
{/* dropdown */}
            <div className="dropdown">
              <a className="btn " href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown">
              <img className='navbar-profile-pic' alt="profile pic" src="https://images.unsplash.com/photo-1484081064812-86e90e107fa8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"></img>
              </a>

              <ul className="dropdown-menu" aria-labelledby="dropdownMenuLink">
                <li><NavLink className="dropdown-item mt-0" to="/myprofile">My Profile</NavLink></li>
                <li><a className="dropdown-item" href="#">Log out</a></li>

              </ul>
            </div>
            
            {/* <button className="btn btn-outline-success" type="submit">Search</button> */}
          </form>
        </div>
      </nav>
    </div>
  )
}

export default NavBar