import React from 'react'
import "../components/Card.css"
import moreAction from '../images/more-action.PNG'
function Cards() {
    return (
        <div>
            <div className='card shadow-sm'>
                <div className='card-body px-2'>

                    <div className='row'>
                        <div className='col-6 d-flex'>
                            <img className='p-2 profile-picCard' alt="profile pic" src="https://images.unsplash.com/photo-1484081064812-86e90e107fa8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"></img>
                            <div className='mt-2'>
                                <p className='fs-6 fw-bold'>Title</p>
                                <p className='location'>Description</p>
                            </div>
                        </div>
                        <div className='col-6'>
                            <img class="float-end fs-3 p-2 mt-2" alt="more action" src={moreAction} />

                        </div>
                        <div className='row'>
                            <div className='col-12'>
                                <img style={{ borderRadius: '15px' }} className='p-2 img-fluid' alt="post pic" src="https://plus.unsplash.com/premium_photo-1690164161389-1921e4981b69?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwzfHx8ZW58MHx8fHx8&auto=format&fit=crop&w=1000&q=60" />
                            </div>

                        </div>

                        <div className='row mt-2'>
                        <div className='col-6 d-flex ps-4 fs-5'>
                        <i class="fa-regular fa-heart "></i>
                        <i class="fa-regular fa-comment ms-3"></i>
                        <i class="fa-solid fa-location-arrow ms-3"></i>
                        </div>
                        <div className='col-6'>
                            <span className='pe-2  fw-bold float-end'>200 likes</span>
                        </div>
                        

                    </div>
                    
                    <div className='row'>
                        <div className='col-12'>
                            <span className='p-2 text-muted'>2 Hours Ago</span>
                        </div>
                    </div>


                    </div>

                </div>

            </div>
        </div>


    )
}

export default Cards